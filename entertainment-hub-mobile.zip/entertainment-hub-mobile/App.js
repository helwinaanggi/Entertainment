import { ActivityIndicator, View } from 'react-native';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider, useAuth } from './src/auth';
import { c } from './src/ui';
import Register from './src/screens/Register';
import Login from './src/screens/Login';
import Home from './src/screens/Home';
import Detail from './src/screens/Detail';
import Favorites from './src/screens/Favorites';

const Stack = createNativeStackNavigator(), Tab = createBottomTabNavigator();
const theme = { ...DarkTheme, colors: { ...DarkTheme.colors, background: c.bg, card: c.sf, text: c.tx, border: c.ln, primary: c.ac } };
const tabLabel = (title) => ({ title, tabBarIcon: () => null, tabBarLabelPosition: 'beside-icon', tabBarActiveTintColor: c.ac, tabBarInactiveTintColor: c.mu, tabBarLabelStyle: { fontSize: 13, fontWeight: '600' }, headerShown: false });
function Tabs() {
  return (
    <Tab.Navigator screenOptions={{ tabBarStyle: { height: 60 } }}>
      <Tab.Screen name="Beranda" component={Home} options={tabLabel('Beranda')} />
      <Tab.Screen name="Favorit" component={Favorites} options={tabLabel('Favorit')} />
    </Tab.Navigator>
  );
}
function Root() {
  const { user, ready } = useAuth();
  if (!ready) return <View style={{ flex: 1, backgroundColor: c.bg, justifyContent: 'center' }}><ActivityIndicator color={c.ac} /></View>;
  return (
    <Stack.Navigator>
      {user ? (
        <>
          <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
          <Stack.Screen name="Detail" component={Detail} options={{ title: 'Detail', headerBackTitle: 'Kembali' }} />
        </>
      ) : (
        <>
          <Stack.Screen name="Login" component={Login} options={{ title: 'Masuk' }} />
          <Stack.Screen name="Register" component={Register} options={{ title: 'Daftar' }} />
        </>
      )}
    </Stack.Navigator>
  );
}
export default function App() {
  return (
    <AuthProvider>
      <NavigationContainer theme={theme}><StatusBar style="light" /><Root /></NavigationContainer>
    </AuthProvider>
  );
}
