# Entertainment Hub Mobile (React Native + Expo)

Layar: Register, Login, Beranda, Detail, Favorit. Memakai API backend yang sama dengan versi web (folder `backend`).

## Menjalankan
1. Jalankan backend dulu (`npm run seed` lalu `npm start` di folder backend, port 5000).
2. Di folder ini:
   ```
   npm install
   npx expo install --fix   # menyelaraskan versi paket dengan SDK Expo
   npx expo start
   ```
3. Buka di emulator (tekan `a` untuk Android, `i` untuk iOS) atau pindai QR dengan aplikasi Expo Go.

## Alamat API
Atur di `src/config.js`. Emulator Android memakai `10.0.2.2`. HP fisik harus memakai IP komputer di jaringan yang sama
(mis. `http://192.168.1.10:5000/api`), dan komputer serta HP berada pada Wi-Fi yang sama.
