import { useCallback, useState } from 'react';
import { FlatList, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { api } from '../api';
import { Button, s } from '../ui';
import { useAuth } from '../auth';
import Poster from './Poster';
export default function Favorites({ navigation }) {
  const { logout } = useAuth();
  const [items, setItems] = useState([]), [err, setErr] = useState('');
  const load = useCallback(() => api('/favorites').then((d) => { setErr(''); setItems(d); }).catch((e) => setErr(e.message)), []);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  const remove = (id) => api('/favorites/' + id, { method: 'DELETE' }).then(load).catch((e) => setErr(e.message));
  return (
    <View style={s.screen}>
      <FlatList data={items} numColumns={2} keyExtractor={(i) => i.id} contentContainerStyle={{ padding: 16 }}
        ListHeaderComponent={<View style={{ gap: 12, padding: 8 }}><Text style={s.h1}>Favorit saya</Text>{err ? <Text style={s.err}>{err}</Text> : null}</View>}
        ListEmptyComponent={<Text style={[s.mu, { padding: 8 }]}>Belum ada favorit. Buka halaman detail lalu pilih Tambah ke favorit.</Text>}
        ListFooterComponent={<View style={{ padding: 8, marginTop: 16 }}><Button outline title="Keluar" onPress={logout} /></View>}
        renderItem={({ item }) => <Poster item={item} onPress={() => navigation.navigate('Detail', { id: item.id })} onRemove={() => remove(item.id)} />} />
    </View>
  );
}
