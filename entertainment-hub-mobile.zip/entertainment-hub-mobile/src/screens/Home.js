import { useCallback, useState } from 'react';
import { FlatList, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { api } from '../api';
import { Chip, Field, s } from '../ui';
import Poster from './Poster';
const TABS = [['', 'Semua'], ['movie', 'Film'], ['series', 'Serial'], ['music', 'Musik']];
export default function Home({ navigation }) {
  const [items, setItems] = useState([]), [type, setType] = useState(''), [q, setQ] = useState(''), [err, setErr] = useState('');
  useFocusEffect(useCallback(() => {
    const t = setTimeout(() => api(`/contents?type=${type}&q=${encodeURIComponent(q)}`).then((d) => { setErr(''); setItems(d); }).catch((e) => setErr(e.message)), 250);
    return () => clearTimeout(t);
  }, [type, q]));
  return (
    <View style={s.screen}>
      <FlatList data={items} numColumns={2} keyExtractor={(i) => i.id} contentContainerStyle={{ padding: 16 }}
        ListHeaderComponent={<View style={{ gap: 16, padding: 8, paddingBottom: 12 }}>
          <Text style={s.h1}>Jelajahi konten</Text>
          <Field placeholder="Cari film, serial, atau musik" value={q} onChangeText={setQ} />
          <View style={s.row}>{TABS.map(([k, l]) => <Chip key={k} label={l} on={type === k} onPress={() => setType(k)} />)}</View>
          {err ? <Text style={s.err}>{err}</Text> : null}
        </View>}
        ListEmptyComponent={!err ? <Text style={[s.mu, { padding: 8 }]}>Konten tidak ditemukan. Coba kata kunci lain.</Text> : null}
        renderItem={({ item }) => <Poster item={item} onPress={() => navigation.navigate('Detail', { id: item.id })} />} />
    </View>
  );
}
