import { useCallback, useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { useFocusEffect } from '@react-navigation/native';
import { api } from '../api';
import { Button, c, Field, s, TYPE } from '../ui';
export default function Detail({ route }) {
  const { id } = route.params;
  const [d, setD] = useState(null), [err, setErr] = useState(''), [text, setText] = useState('');
  const load = useCallback(() => api('/contents/' + id).then((x) => { setErr(''); setD(x); }).catch((e) => setErr(e.message)), [id]);
  useFocusEffect(useCallback(() => { load(); }, [load]));
  const run = (fn) => fn().then(load).catch((e) => setErr(e.message));
  if (!d) return <View style={[s.screen, s.pad]}><Text style={err ? s.err : s.mu}>{err || 'Memuat...'}</Text></View>;
  return (
    <ScrollView style={s.screen}>
      {d.trailerUrl
        ? <WebView source={{ uri: d.trailerUrl }} style={{ height: 220, backgroundColor: c.ln }} allowsFullscreenVideo />
        : <View style={{ height: 220, backgroundColor: d.color, justifyContent: 'center', alignItems: 'center' }}><Text style={{ color: '#fff' }}>Trailer belum tersedia</Text></View>}
      <View style={s.pad}>
        <Text style={s.h1}>{d.title}</Text>
        <Text style={s.mu}>{TYPE[d.type]} - {d.year} - {d.genre.join(', ')}</Text>
        <Text style={{ color: c.ac, fontWeight: '600' }}>★ {d.avg} <Text style={s.mu}>({d.count} rating)</Text></Text>
        <Button title={d.isFavorite ? 'Hapus dari favorit' : 'Tambah ke favorit'} onPress={() => run(() => api('/favorites/' + id, { method: d.isFavorite ? 'DELETE' : 'POST' }))} />
        <Text style={s.label}>Beri rating Anda</Text>
        <View style={{ flexDirection: 'row' }}>{[1, 2, 3, 4, 5].map((n) => (
          <Pressable key={n} accessibilityLabel={'Beri rating ' + n} onPress={() => run(() => api(`/contents/${id}/rate`, { method: 'POST', body: { value: n } }))} style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 28, color: n <= d.myRating ? c.ac : c.mu }}>★</Text>
          </Pressable>))}</View>
        <Text style={s.h2}>Sinopsis</Text><Text style={s.mu}>{d.synopsis}</Text>
        <Text style={s.h2}>Ulasan</Text>
        <Field placeholder="Tulis ulasan Anda" multiline value={text} onChangeText={setText} style={[s.input, { height: 96, paddingTop: 12, textAlignVertical: 'top' }]} />
        <Button outline title="Kirim ulasan" onPress={() => run(() => api(`/contents/${id}/reviews`, { method: 'POST', body: { text } })).then(() => setText(''))} />
        {err ? <Text style={s.err}>{err}</Text> : null}
        {d.reviews.map((r) => (
          <View key={r.id} style={{ backgroundColor: c.sf, borderWidth: 1, borderColor: c.ln, borderRadius: 12, padding: 14, gap: 4 }}>
            <Text style={{ color: c.tx, fontWeight: '600' }}>{r.name}</Text><Text style={s.mu}>{r.text}</Text>
          </View>))}
        {!d.reviews.length ? <Text style={s.mu}>Belum ada ulasan. Jadilah yang pertama.</Text> : null}
      </View>
    </ScrollView>
  );
}
