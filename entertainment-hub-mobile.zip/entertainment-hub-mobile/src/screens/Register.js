import { useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useAuth } from '../auth';
import { Button, Chip, Field, s } from '../ui';
const INTERESTS = ['Film', 'Serial', 'Musik', 'Aksi', 'Drama', 'Pop'];
export default function Register({ navigation }) {
  const { register } = useAuth();
  const [f, setF] = useState({ name: '', email: '', password: '', interests: [] }), [err, setErr] = useState('');
  const toggle = (g) => setF({ ...f, interests: f.interests.includes(g) ? f.interests.filter((x) => x !== g) : [...f.interests, g] });
  const submit = async () => { setErr(''); try { await register(f); } catch (e) { setErr(e.message); } };
  return (
    <ScrollView style={s.screen} contentContainerStyle={s.pad} keyboardShouldPersistTaps="handled">
      <Text style={s.h1}>Buat akun baru</Text>
      <Text style={s.mu}>Simpan favorit dan dapatkan rekomendasi sesuai selera Anda.</Text>
      <Field label="Nama lengkap" placeholder="Nama Anda" value={f.name} onChangeText={(v) => setF({ ...f, name: v })} autoCapitalize="words" />
      <Field label="Email" placeholder="nama@email.com" keyboardType="email-address" value={f.email} onChangeText={(v) => setF({ ...f, email: v })} />
      <Field label="Kata sandi" placeholder="Minimal 8 karakter" secureTextEntry value={f.password} onChangeText={(v) => setF({ ...f, password: v })} />
      <Text style={s.label}>Pilih minat Anda</Text>
      <View style={s.row}>{INTERESTS.map((g) => <Chip key={g} label={g} on={f.interests.includes(g)} onPress={() => toggle(g)} />)}</View>
      {err ? <Text style={s.err} accessibilityRole="alert">{err}</Text> : null}
      <Button title="Daftar" onPress={submit} />
      <Text style={[s.mu, { textAlign: 'center' }]} onPress={() => navigation.navigate('Login')}>Sudah punya akun? <Text style={{ color: '#F5A524', fontWeight: '600' }}>Masuk</Text></Text>
    </ScrollView>
  );
}
