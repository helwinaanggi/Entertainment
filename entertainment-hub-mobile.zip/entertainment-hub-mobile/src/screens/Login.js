import { useState } from 'react';
import { ScrollView, Text } from 'react-native';
import { useAuth } from '../auth';
import { Button, Field, s } from '../ui';
export default function Login({ navigation }) {
  const { login } = useAuth();
  const [f, setF] = useState({ email: '', password: '' }), [err, setErr] = useState('');
  const submit = async () => { setErr(''); try { await login(f); } catch (e) { setErr(e.message); } };
  return (
    <ScrollView style={s.screen} contentContainerStyle={[s.pad, { flexGrow: 1, justifyContent: 'center' }]} keyboardShouldPersistTaps="handled">
      <Text style={s.h1}>Selamat datang kembali</Text>
      <Text style={s.mu}>Masuk untuk membuka daftar favorit dan rekomendasi Anda.</Text>
      <Field label="Email" placeholder="nama@email.com" keyboardType="email-address" value={f.email} onChangeText={(v) => setF({ ...f, email: v })} />
      <Field label="Kata sandi" placeholder="Kata sandi Anda" secureTextEntry value={f.password} onChangeText={(v) => setF({ ...f, password: v })} />
      {err ? <Text style={s.err} accessibilityRole="alert">{err}</Text> : null}
      <Button title="Masuk" onPress={submit} />
      <Text style={[s.mu, { textAlign: 'center' }]} onPress={() => navigation.navigate('Register')}>Belum punya akun? <Text style={{ color: '#F5A524', fontWeight: '600' }}>Daftar</Text></Text>
    </ScrollView>
  );
}
