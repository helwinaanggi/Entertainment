import { Pressable, Text, View } from 'react-native';
import { c, s, TYPE } from '../ui';
export default function Poster({ item, onPress, onRemove }) {
  return (
    <View style={{ flex: 1, margin: 8, maxWidth: '50%' }}>
      <Pressable onPress={onPress} accessibilityLabel={item.title} style={{ aspectRatio: 2 / 3, borderRadius: 12, backgroundColor: item.color, justifyContent: 'flex-end', padding: 10 }}>
        <Text style={{ color: '#fff', fontWeight: '600' }}>{item.title}</Text>
      </Pressable>
      <Text style={[s.mu, { fontSize: 12, marginTop: 4 }]}>{TYPE[item.type]} - {item.year}{item.count ? ` - ★ ${item.avg}` : ''}</Text>
      {onRemove ? <Text onPress={onRemove} accessibilityRole="button" style={{ color: c.ac, fontWeight: '600', paddingVertical: 12 }}>Hapus</Text> : null}
    </View>
  );
}
