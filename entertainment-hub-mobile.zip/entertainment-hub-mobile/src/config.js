import { Platform } from 'react-native';
// Emulator Android memakai 10.0.2.2. Untuk HP fisik, ganti dengan IP komputer Anda, mis. http://192.168.1.10:5000/api
export const API_URL = Platform.OS === 'android' ? 'http://10.0.2.2:5000/api' : 'http://localhost:5000/api';
