import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_URL } from './config';
export async function api(path, { method = 'GET', body } = {}) {
  const token = await AsyncStorage.getItem('token');
  let res;
  try {
    res = await fetch(API_URL + path, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token && { Authorization: 'Bearer ' + token }) },
      body: body && JSON.stringify(body),
    });
  } catch { throw new Error('Tidak dapat terhubung ke server. Periksa koneksi dan alamat API.'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || 'Terjadi kesalahan.');
  return data;
}
