import { Pressable, Text, TextInput, View, StyleSheet } from 'react-native';
export const c = { bg: '#0F1115', sf: '#1A1D24', tx: '#F2F3F5', mu: '#A9AFBB', ac: '#F5A524', ln: '#2A2F3A', dk: '#1A1203' };
export const TYPE = { movie: 'Film', series: 'Serial', music: 'Musik' };
export const Button = ({ title, onPress, outline }) => (
  <Pressable accessibilityRole="button" onPress={onPress} style={[s.btn, outline && s.outline]}>
    <Text style={[s.btnTx, outline && { color: c.ac }]}>{title}</Text>
  </Pressable>
);
export const Field = ({ label, ...p }) => (
  <View style={{ gap: 6 }}>
    {label ? <Text style={s.label}>{label}</Text> : null}
    <TextInput placeholderTextColor={c.mu} autoCapitalize="none" style={s.input} accessibilityLabel={label || p.placeholder} {...p} />
  </View>
);
export const Chip = ({ label, on, onPress }) => (
  <Pressable onPress={onPress} accessibilityState={{ selected: on }} style={[s.chip, on && { backgroundColor: c.ac, borderColor: c.ac }]}>
    <Text style={{ color: on ? c.dk : c.tx, fontWeight: '500' }}>{label}</Text>
  </Pressable>
);
export const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: c.bg }, pad: { padding: 24, gap: 16 },
  h1: { color: c.tx, fontSize: 26, fontWeight: '700' }, h2: { color: c.tx, fontSize: 17, fontWeight: '600', marginTop: 8 },
  mu: { color: c.mu, fontSize: 14, lineHeight: 21 }, err: { color: '#FF8A80' }, label: { color: c.mu, fontSize: 13 },
  input: { height: 48, borderRadius: 12, borderWidth: 1, borderColor: c.ln, backgroundColor: c.sf, color: c.tx, paddingHorizontal: 14, fontSize: 15 },
  btn: { height: 48, borderRadius: 12, backgroundColor: c.ac, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: c.ac },
  outline: { backgroundColor: 'transparent' }, btnTx: { color: c.dk, fontWeight: '600', fontSize: 16 },
  chip: { minHeight: 44, paddingHorizontal: 16, borderRadius: 22, borderWidth: 1, borderColor: c.ln, backgroundColor: c.sf, justifyContent: 'center' },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
});
