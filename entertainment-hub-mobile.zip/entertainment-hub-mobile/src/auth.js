import { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { api } from './api';
const Ctx = createContext();
export const useAuth = () => useContext(Ctx);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null), [ready, setReady] = useState(false);
  useEffect(() => { AsyncStorage.getItem('user').then((u) => { if (u) setUser(JSON.parse(u)); setReady(true); }); }, []);
  const save = async (d) => { await AsyncStorage.multiSet([['token', d.token], ['user', JSON.stringify(d.user)]]); setUser(d.user); };
  const login = async (body) => save(await api('/auth/login', { method: 'POST', body }));
  const register = async (body) => save(await api('/auth/register', { method: 'POST', body }));
  const logout = async () => { await AsyncStorage.multiRemove(['token', 'user']); setUser(null); };
  return <Ctx.Provider value={{ user, ready, login, register, logout }}>{children}</Ctx.Provider>;
}
