# Entertainment Hub (React + Express + MongoDB)

Halaman web: Register, Login, Beranda, Detail konten, Favorit.

## Menjalankan
1. Pastikan MongoDB aktif (lokal atau Atlas).
2. Backend
   ```
   cd backend
   npm install
   cp .env.example .env   # isi MONGO_URI dan JWT_SECRET
   npm run seed           # isi data contoh
   npm start              # http://localhost:5000
   ```
3. Frontend (terminal lain)
   ```
   cd frontend
   npm install
   npm run dev            # http://localhost:5173
   ```

## Endpoint
POST /api/auth/register, POST /api/auth/login, GET /api/contents?type=&q=, GET /api/contents/:id,
POST /api/contents/:id/rate, POST /api/contents/:id/reviews, GET /api/favorites, POST|DELETE /api/favorites/:id

## Catatan
- Data konten adalah contoh. Isi `trailerUrl` dengan URL embed (mis. https://www.youtube.com/embed/ID_VIDEO) agar trailer tampil.
- Aplikasi mobile (React Native) dapat memakai API yang sama.
