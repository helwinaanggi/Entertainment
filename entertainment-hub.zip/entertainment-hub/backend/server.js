require('dotenv').config();
const express = require('express'), cors = require('cors'), mongoose = require('mongoose');
const bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken');
const { User, Content } = require('./models');

const app = express();
app.use(cors(), express.json());
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
const bad = (res, msg, code = 400) => res.status(code).json({ message: msg });
const sign = (u) => jwt.sign({ id: u._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
const pub = (u) => ({ id: u._id, name: u.name, email: u.email, interests: u.interests });
const card = (c) => {
  const n = c.ratings.length;
  return { id: c._id, title: c.title, type: c.type, year: c.year, genre: c.genre, color: c.color,
    avg: n ? +(c.ratings.reduce((a, r) => a + r.value, 0) / n).toFixed(1) : 0, count: n };
};
const auth = (req, res, next) => {
  try { req.uid = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), process.env.JWT_SECRET).id; next(); }
  catch { bad(res, 'Silakan login terlebih dahulu.', 401); }
};

// --- Autentikasi
app.post('/api/auth/register', wrap(async (req, res) => {
  const { name, email, password, interests = [] } = req.body;
  if (!name || !email || !password || password.length < 8) return bad(res, 'Nama, email, dan kata sandi (min. 8 karakter) wajib diisi.');
  if (await User.findOne({ email })) return bad(res, 'Email sudah terdaftar.', 409);
  const u = await User.create({ name, email, interests, password: await bcrypt.hash(password, 10) });
  res.status(201).json({ token: sign(u), user: pub(u) });
}));
app.post('/api/auth/login', wrap(async (req, res) => {
  const u = await User.findOne({ email: (req.body.email || '').toLowerCase() });
  if (!u || !(await bcrypt.compare(req.body.password || '', u.password))) return bad(res, 'Email atau kata sandi salah.', 401);
  res.json({ token: sign(u), user: pub(u) });
}));

// --- Konten
app.get('/api/contents', auth, wrap(async (req, res) => {
  const { type, q } = req.query, f = {};
  if (type) f.type = type;
  if (q) f.title = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
  res.json((await Content.find(f).sort({ year: -1 })).map(card));
}));
app.get('/api/contents/:id', auth, wrap(async (req, res) => {
  const c = await Content.findById(req.params.id);
  if (!c) return bad(res, 'Konten tidak ditemukan.', 404);
  const u = await User.findById(req.uid);
  const mine = c.ratings.find((r) => String(r.user) === req.uid);
  res.json({ ...card(c), synopsis: c.synopsis, trailerUrl: c.trailerUrl, myRating: mine ? mine.value : 0,
    isFavorite: u.favorites.some((x) => String(x) === req.params.id),
    reviews: [...c.reviews].reverse().map((r) => ({ id: r._id, name: r.name, text: r.text, at: r.at })) });
}));
app.post('/api/contents/:id/rate', auth, wrap(async (req, res) => {
  const v = Number(req.body.value);
  if (!(v >= 1 && v <= 5)) return bad(res, 'Rating harus 1 sampai 5.');
  const c = await Content.findById(req.params.id);
  if (!c) return bad(res, 'Konten tidak ditemukan.', 404);
  const mine = c.ratings.find((r) => String(r.user) === req.uid);
  mine ? (mine.value = v) : c.ratings.push({ user: req.uid, value: v });
  await c.save();
  res.json(card(c));
}));
app.post('/api/contents/:id/reviews', auth, wrap(async (req, res) => {
  const text = (req.body.text || '').trim();
  if (text.length < 3 || text.length > 500) return bad(res, 'Ulasan harus 3 sampai 500 karakter.');
  const [c, u] = await Promise.all([Content.findById(req.params.id), User.findById(req.uid)]);
  if (!c) return bad(res, 'Konten tidak ditemukan.', 404);
  c.reviews.push({ user: u._id, name: u.name, text });
  await c.save();
  res.status(201).json({ ok: true });
}));

// --- Favorit
app.get('/api/favorites', auth, wrap(async (req, res) => {
  const u = await User.findById(req.uid).populate('favorites');
  res.json(u.favorites.map(card));
}));
app.post('/api/favorites/:id', auth, wrap(async (req, res) => {
  await User.updateOne({ _id: req.uid }, { $addToSet: { favorites: req.params.id } });
  res.json({ ok: true });
}));
app.delete('/api/favorites/:id', auth, wrap(async (req, res) => {
  await User.updateOne({ _id: req.uid }, { $pull: { favorites: req.params.id } });
  res.json({ ok: true });
}));

app.use((err, req, res, next) => bad(res, err.name === 'CastError' ? 'ID tidak valid.' : 'Terjadi kesalahan pada server.', err.name === 'CastError' ? 400 : 500));
mongoose.connect(process.env.MONGO_URI).then(() => {
  const port = process.env.PORT || 5000;
  app.listen(port, () => console.log('API berjalan di http://localhost:' + port));
}).catch((e) => { console.error('Gagal terhubung ke MongoDB', e.message); process.exit(1); });
