const { Schema, model } = require('mongoose');
const ref = { type: Schema.Types.ObjectId };
const User = model('User', new Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
  interests: [String],
  favorites: [{ ...ref, ref: 'Content' }],
}, { timestamps: true }));
const Content = model('Content', new Schema({
  title: { type: String, required: true },
  type: { type: String, enum: ['movie', 'series', 'music'], required: true },
  year: Number,
  genre: [String],
  synopsis: String,
  color: { type: String, default: '#3B4A6B' },
  trailerUrl: String, // URL embed, mis. https://www.youtube.com/embed/ID_VIDEO
  ratings: [{ user: ref, value: { type: Number, min: 1, max: 5 } }],
  reviews: [{ user: ref, name: String, text: String, at: { type: Date, default: Date.now } }],
}));
module.exports = { User, Content };
