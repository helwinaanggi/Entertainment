require('dotenv').config();
const mongoose = require('mongoose');
const { Content } = require('./models');
const d = 'Contoh deskripsi konten. Ganti dengan data asli atau hubungkan ke API publik.';
const data = [
  { title: 'Judul Film A', type: 'movie', year: 2024, genre: ['Drama'], color: '#3B4A6B' },
  { title: 'Judul Film D', type: 'movie', year: 2023, genre: ['Aksi'], color: '#6B4E2E' },
  { title: 'Serial B', type: 'series', year: 2024, genre: ['Aksi'], color: '#5B3A4A' },
  { title: 'Serial E', type: 'series', year: 2022, genre: ['Drama'], color: '#3B4A6B' },
  { title: 'Album C', type: 'music', year: 2024, genre: ['Pop'], color: '#2F5D50' },
  { title: 'Album F', type: 'music', year: 2021, genre: ['Pop'], color: '#6B4E2E' },
].map((x) => ({ ...x, synopsis: d, trailerUrl: '' }));
mongoose.connect(process.env.MONGO_URI).then(async () => {
  await Content.deleteMany({});
  await Content.insertMany(data);
  console.log('Seed selesai:', data.length, 'konten');
  process.exit(0);
});
