import { BrowserRouter, Routes, Route, Navigate, NavLink } from 'react-router-dom';
import { AuthProvider, useAuth } from './auth';
import Register from './pages/Register';
import Login from './pages/Login';
import Home from './pages/Home';
import Detail from './pages/Detail';
import Favorites from './pages/Favorites';

const Private = ({ children }) => (useAuth().user ? children : <Navigate to="/login" replace />);
function Nav() {
  const { user, logout } = useAuth();
  if (!user) return null;
  return (
    <header className="nav">
      <strong className="brand">Entertainment Hub</strong>
      <nav><NavLink to="/" end>Beranda</NavLink><NavLink to="/favorites">Favorit</NavLink></nav>
      <button className="link" onClick={logout}>Keluar ({user.name})</button>
    </header>
  );
}
export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Nav />
        <Routes>
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Private><Home /></Private>} />
          <Route path="/content/:id" element={<Private><Detail /></Private>} />
          <Route path="/favorites" element={<Private><Favorites /></Private>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
