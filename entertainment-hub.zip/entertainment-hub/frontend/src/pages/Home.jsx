import { useEffect, useState } from 'react';
import { api } from '../api';
import Card from './Card';
const TABS = [['', 'Semua'], ['movie', 'Film'], ['series', 'Serial'], ['music', 'Musik']];
export default function Home() {
  const [items, setItems] = useState([]), [type, setType] = useState(''), [q, setQ] = useState(''), [err, setErr] = useState('');
  useEffect(() => {
    const t = setTimeout(() => api(`/contents?type=${type}&q=${encodeURIComponent(q)}`).then(setItems).catch((e) => setErr(e.message)), 250);
    return () => clearTimeout(t);
  }, [type, q]);
  return (
    <main className="page">
      <h1>Jelajahi film, serial, dan musik</h1>
      <input className="search" type="search" aria-label="Cari konten" placeholder="Cari film, serial, atau musik" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="chips">{TABS.map(([k, l]) => <button key={k} className="chip" aria-pressed={type === k} onClick={() => setType(k)}>{l}</button>)}</div>
      {err && <p role="alert" className="error">{err}</p>}
      <div className="grid">{items.map((c) => <Card key={c.id} c={c} />)}</div>
      {!err && !items.length && <p className="muted">Konten tidak ditemukan. Coba kata kunci lain.</p>}
    </main>
  );
}
