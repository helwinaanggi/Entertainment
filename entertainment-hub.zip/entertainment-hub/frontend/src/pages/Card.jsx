import { Link } from 'react-router-dom';
export const TYPE = { movie: 'Film', series: 'Serial', music: 'Musik' };
export default function Card({ c, onRemove }) {
  return (
    <div className="card">
      <Link to={'/content/' + c.id} className="poster" style={{ background: c.color }}><span>{c.title}</span></Link>
      <div className="meta">{TYPE[c.type]} - {c.year}{c.count ? ` - ★ ${c.avg}` : ''}</div>
      {onRemove && <button className="link" onClick={() => onRemove(c.id)} aria-label={'Hapus ' + c.title + ' dari favorit'}>Hapus</button>}
    </div>
  );
}
