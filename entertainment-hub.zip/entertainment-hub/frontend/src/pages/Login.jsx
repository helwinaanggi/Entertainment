import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth';
export default function Login() {
  const { login } = useAuth(), nav = useNavigate();
  const [f, setF] = useState({ email: '', password: '' });
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => { e.preventDefault(); setErr(''); try { await login(f); nav('/'); } catch (x) { setErr(x.message); } };
  return (
    <main className="auth">
      <form onSubmit={submit}>
        <h1>Selamat datang kembali</h1>
        <p className="muted">Masuk untuk membuka daftar favorit dan rekomendasi Anda.</p>
        <label>Email<input required type="email" value={f.email} onChange={set('email')} placeholder="nama@email.com" /></label>
        <label>Kata sandi<input required type="password" value={f.password} onChange={set('password')} placeholder="Kata sandi Anda" /></label>
        {err && <p role="alert" className="error">{err}</p>}
        <button className="btn">Masuk</button>
        <p className="muted center">Belum punya akun? <Link to="/register">Daftar</Link></p>
      </form>
    </main>
  );
}
