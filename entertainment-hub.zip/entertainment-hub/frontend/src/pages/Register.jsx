import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth';
const INTERESTS = ['Film', 'Serial', 'Musik', 'Aksi', 'Drama', 'Pop'];
export default function Register() {
  const { register } = useAuth(), nav = useNavigate();
  const [f, setF] = useState({ name: '', email: '', password: '', interests: [] });
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const toggle = (g) => setF({ ...f, interests: f.interests.includes(g) ? f.interests.filter((x) => x !== g) : [...f.interests, g] });
  const submit = async (e) => { e.preventDefault(); setErr(''); try { await register(f); nav('/'); } catch (x) { setErr(x.message); } };
  return (
    <main className="auth">
      <form onSubmit={submit}>
        <h1>Buat akun baru</h1>
        <p className="muted">Simpan favorit dan dapatkan rekomendasi sesuai selera Anda.</p>
        <label>Nama lengkap<input required value={f.name} onChange={set('name')} placeholder="Nama Anda" /></label>
        <label>Email<input required type="email" value={f.email} onChange={set('email')} placeholder="nama@email.com" /></label>
        <label>Kata sandi<input required type="password" minLength={8} value={f.password} onChange={set('password')} placeholder="Minimal 8 karakter" /></label>
        <div className="muted">Pilih minat Anda</div>
        <div className="chips">
          {INTERESTS.map((g) => <button type="button" key={g} aria-pressed={f.interests.includes(g)} className="chip" onClick={() => toggle(g)}>{g}</button>)}
        </div>
        {err && <p role="alert" className="error">{err}</p>}
        <button className="btn">Daftar</button>
        <p className="muted center">Sudah punya akun? <Link to="/login">Masuk</Link></p>
      </form>
    </main>
  );
}
