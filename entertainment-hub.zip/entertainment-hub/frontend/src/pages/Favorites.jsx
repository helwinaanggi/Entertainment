import { useEffect, useState } from 'react';
import { api } from '../api';
import Card from './Card';
export default function Favorites() {
  const [items, setItems] = useState([]), [err, setErr] = useState('');
  const load = () => api('/favorites').then(setItems).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []);
  const remove = (id) => api('/favorites/' + id, { method: 'DELETE' }).then(load).catch((e) => setErr(e.message));
  return (
    <main className="page">
      <h1>Favorit saya</h1>
      {err && <p role="alert" className="error">{err}</p>}
      <div className="grid">{items.map((c) => <Card key={c.id} c={c} onRemove={remove} />)}</div>
      {!items.length && <p className="muted">Belum ada favorit. Buka halaman detail lalu pilih Tambah ke favorit.</p>}
    </main>
  );
}
