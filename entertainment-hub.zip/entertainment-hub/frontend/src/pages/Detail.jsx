import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api';
import { TYPE } from './Card';
export default function Detail() {
  const { id } = useParams();
  const [d, setD] = useState(null), [err, setErr] = useState(''), [text, setText] = useState('');
  const load = () => api('/contents/' + id).then(setD).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, [id]);
  const run = (fn) => fn().then(load).catch((e) => setErr(e.message));
  const rate = (value) => run(() => api(`/contents/${id}/rate`, { method: 'POST', body: { value } }));
  const fav = () => run(() => api('/favorites/' + id, { method: d.isFavorite ? 'DELETE' : 'POST' }));
  const review = (e) => { e.preventDefault(); run(() => api(`/contents/${id}/reviews`, { method: 'POST', body: { text } })).then(() => setText('')); };
  if (err && !d) return <main className="page"><p role="alert" className="error">{err}</p></main>;
  if (!d) return <main className="page"><p className="muted">Memuat...</p></main>;
  return (
    <main className="page detail">
      <Link to="/" className="muted">Kembali</Link>
      {d.trailerUrl
        ? <iframe className="trailer" src={d.trailerUrl} title={'Trailer ' + d.title} allowFullScreen />
        : <div className="trailer empty" style={{ background: d.color }}>Trailer belum tersedia</div>}
      <h1>{d.title}</h1>
      <p className="muted">{TYPE[d.type]} - {d.year} - {d.genre.join(', ')}</p>
      <p className="avg">★ {d.avg} <span className="muted">({d.count} rating)</span></p>
      <button className="btn" onClick={fav}>{d.isFavorite ? 'Hapus dari favorit' : 'Tambah ke favorit'}</button>
      <h2>Beri rating Anda</h2>
      <div className="stars">{[1, 2, 3, 4, 5].map((n) => <button key={n} aria-label={'Beri rating ' + n} className={n <= d.myRating ? 'on' : ''} onClick={() => rate(n)}>★</button>)}</div>
      <h2>Sinopsis</h2><p className="muted">{d.synopsis}</p>
      <h2>Ulasan</h2>
      <form onSubmit={review} className="reviewform">
        <label>Tulis ulasan<textarea required minLength={3} maxLength={500} value={text} onChange={(e) => setText(e.target.value)} /></label>
        <button className="btn outline">Kirim ulasan</button>
      </form>
      {err && <p role="alert" className="error">{err}</p>}
      {d.reviews.map((r) => <article key={r.id} className="review"><strong>{r.name}</strong><p className="muted">{r.text}</p></article>)}
      {!d.reviews.length && <p className="muted">Belum ada ulasan. Jadilah yang pertama.</p>}
    </main>
  );
}
