process.env.DB_FILE = ':memory:';
process.env.JWT_SECRET = 'test-secret';
const { test, before, after } = require('node:test');
const assert = require('node:assert');
const crypto = require('crypto');
const db = require('../src/db');
const app = require('../src/server');
require('../src/seed');

let base, server, token, movieId;
before(() => new Promise((r) => { server = app.listen(0, () => { base = `http://127.0.0.1:${server.address().port}/api`; r(); }); }));
after(() => server.close());
const call = async (p, { method = 'GET', body, tok = token } = {}) => {
  const res = await fetch(base + p, { method, headers: { 'Content-Type': 'application/json', ...(tok && { Authorization: 'Bearer ' + tok }) }, body: body && JSON.stringify(body) });
  return { status: res.status, data: await res.json() };
};

test('register, duplikat, login', async () => {
  let r = await call('/auth/register', { method: 'POST', body: { name: 'Budi', email: 'Budi@Mail.com', password: 'rahasia123', interests: ['Film'] } });
  assert.equal(r.status, 201); token = r.data.token; assert.equal(r.data.user.email, 'budi@mail.com');
  assert.equal((await call('/auth/register', { method: 'POST', body: { name: 'B', email: 'x', password: '1' } })).status, 400);
  assert.equal((await call('/auth/register', { method: 'POST', body: { name: 'Budi', email: 'budi@mail.com', password: 'rahasia123' } })).status, 409);
  assert.equal((await call('/auth/login', { method: 'POST', body: { email: 'budi@mail.com', password: 'salah' } })).status, 401);
  r = await call('/auth/login', { method: 'POST', body: { email: 'BUDI@mail.com', password: 'rahasia123' } });
  assert.equal(r.status, 200); assert.ok(r.data.token);
});

test('butuh token', async () => {
  assert.equal((await call('/contents', { tok: null })).status, 401);
  assert.equal((await call('/contents', { tok: 'abc' })).status, 401);
});

test('daftar, filter, cari', async () => {
  let r = await call('/contents?type=&q='); assert.equal(r.data.length, 22); movieId = r.data[0].id;
  assert.ok(Array.isArray(r.data[0].genre) && typeof r.data[0].id === 'string');
  r = await call('/contents?type=music'); assert.ok(r.data.every((x) => x.type === 'music'));
  r = await call('/contents?q=inception'); assert.equal(r.data.length, 1);
  r = await call('/contents?q=' + encodeURIComponent('%')); assert.equal(r.data.length, 0); // wildcard di-escape
  assert.equal((await call('/contents?type=foo')).status, 400);
});

test('rating, ulasan, favorit, detail', async () => {
  assert.equal((await call(`/contents/${movieId}/rate`, { method: 'POST', body: { value: 6 } })).status, 400);
  await call(`/contents/${movieId}/rate`, { method: 'POST', body: { value: 4 } });
  await call(`/contents/${movieId}/rate`, { method: 'POST', body: { value: 5 } }); // upsert
  assert.equal((await call(`/contents/${movieId}/reviews`, { method: 'POST', body: { text: '   ' } })).status, 400);
  await call(`/contents/${movieId}/reviews`, { method: 'POST', body: { text: 'Bagus sekali' } });
  assert.equal((await call(`/favorites/${movieId}`, { method: 'POST' })).status, 201);
  assert.equal((await call(`/favorites/${movieId}`, { method: 'POST' })).status, 201); // idempoten
  const d = (await call(`/contents/${movieId}`)).data;
  assert.equal(d.myRating, 5); assert.equal(d.avg, 5); assert.equal(d.count, 1); assert.equal(d.isFavorite, true);
  assert.equal(d.reviews[0].text, 'Bagus sekali'); assert.equal(d.reviews[0].name, 'Budi');
  assert.equal((await call('/favorites')).data.length, 1);
  await call(`/favorites/${movieId}`, { method: 'DELETE' });
  assert.equal((await call('/favorites')).data.length, 0);
  assert.equal((await call('/contents/nope')).status, 404);
  assert.equal((await call(`/favorites/nope`, { method: 'POST' })).status, 404);
});
