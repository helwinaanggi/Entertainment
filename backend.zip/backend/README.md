# Entertainment Hub Backend

API untuk aplikasi `entertainment-hub-mobile`. Node.js + Express + SQLite (file `data/hub.db`, dibuat otomatis).

## Menjalankan
```
npm install
npm run seed     # isi 22 konten contoh (aman dijalankan ulang; `npm run seed:reset` mengosongkan konten dulu)
npm start        # http://0.0.0.0:5000/api
npm test
```
Letakkan folder ini sejajar dengan `entertainment-hub-mobile` (sebagai `backend`). Untuk HP fisik, ubah `src/config.js` di aplikasi ke IP komputer Anda.

## Production
Salin `.env.example` ke `.env`, isi `JWT_SECRET` (`openssl rand -hex 48`), set `NODE_ENV=production`, dan jalankan di belakang HTTPS (reverse proxy). Cadangkan file `data/hub.db`.

## Endpoint (prefix `/api`, error: `{ "message": "..." }`)
| Metode | Path | Keterangan |
|---|---|---|
| POST | /auth/register | `{name,email,password,interests[]}` → `{token,user}` |
| POST | /auth/login | `{email,password}` → `{token,user}` |
| GET | /contents?type=&q= | daftar konten (type: movie/series/music) |
| GET | /contents/:id | detail + `myRating`, `isFavorite`, `reviews` |
| POST | /contents/:id/rate | `{value: 1-5}` (satu rating per pengguna, bisa diubah) |
| POST | /contents/:id/reviews | `{text}` (maks 1000 karakter) |
| GET | /favorites | daftar favorit pengguna |
| POST/DELETE | /favorites/:id | tambah / hapus favorit |
| GET | /health | cek status |

Selain `/auth/*` dan `/health`, semua rute butuh header `Authorization: Bearer <token>`.

## Trailer
Kolom `contents.trailer_url` boleh kosong. Isi dengan URL embed, mis.:
`UPDATE contents SET trailer_url='https://www.youtube.com/embed/<ID>' WHERE title='Inception';`
