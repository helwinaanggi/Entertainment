require('dotenv').config();
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./db');

const PORT = Number(process.env.PORT) || 5000;
const IS_PROD = process.env.NODE_ENV === 'production';

// JWT secret: wajib via env di production; di dev dibuat sekali & disimpan agar token tak hangus saat restart.
function loadSecret() {
  if (process.env.JWT_SECRET) return process.env.JWT_SECRET;
  if (IS_PROD) throw new Error('JWT_SECRET wajib diatur saat NODE_ENV=production');
  const f = path.join(__dirname, '..', 'data', '.jwt_secret');
  if (!fs.existsSync(f)) fs.writeFileSync(f, crypto.randomBytes(48).toString('hex'), { mode: 0o600 });
  return fs.readFileSync(f, 'utf8');
}
const JWT_SECRET = loadSecret();
const TOKEN_TTL = process.env.TOKEN_TTL || '30d';

const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors()); // klien mobile tidak memakai cookie; batasi origin via CORS_ORIGIN bila ada klien web
app.use(express.json({ limit: '20kb' }));

// ---------- helpers ----------
const httpError = (status, message) => Object.assign(new Error(message), { status });
const wrap = (fn) => (req, res, next) => { try { fn(req, res, next); } catch (e) { next(e); } };
const str = (v) => (typeof v === 'string' ? v.trim() : '');
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const DUMMY_HASH = bcrypt.hashSync('dummy-password', 10); // meratakan waktu respons login

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, interests: JSON.parse(u.interests) });
const signToken = (u) => jwt.sign({ sub: u.id }, JWT_SECRET, { expiresIn: TOKEN_TTL });

function auth(req, _res, next) {
  const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
  if (!m) return next(httpError(401, 'Silakan masuk terlebih dahulu.'));
  try {
    const { sub } = jwt.verify(m[1], JWT_SECRET);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(sub);
    if (!user) throw new Error('no user');
    req.user = user;
    next();
  } catch { next(httpError(401, 'Sesi berakhir. Silakan masuk kembali.')); }
}

// ---------- queries ----------
const SUMMARY = `
  SELECT c.id, c.title, c.type, c.year, c.color,
         COALESCE(ROUND((SELECT AVG(value) FROM ratings r WHERE r.content_id = c.id), 1), 0) AS avg,
         (SELECT COUNT(*) FROM ratings r WHERE r.content_id = c.id) AS count
  FROM contents c`;
const genresOf = db.prepare('SELECT genre FROM content_genres WHERE content_id = ? ORDER BY genre');
const withGenres = (row) => ({ ...row, genre: genresOf.all(row.id).map((g) => g.genre) });
const contentExists = db.prepare('SELECT 1 FROM contents WHERE id = ?');
const needContent = (id) => { if (!contentExists.get(id)) throw httpError(404, 'Konten tidak ditemukan.'); };

// ---------- routes ----------
const api = express.Router();
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false, message: { message: 'Terlalu banyak percobaan. Coba lagi nanti.' } });

api.get('/health', (_req, res) => { db.prepare('SELECT 1').get(); res.json({ ok: true }); });

api.post('/auth/register', authLimiter, wrap((req, res) => {
  const name = str(req.body.name), email = str(req.body.email).toLowerCase(), password = typeof req.body.password === 'string' ? req.body.password : '';
  const interests = Array.isArray(req.body.interests) ? [...new Set(req.body.interests.map(str).filter(Boolean))].slice(0, 20) : [];
  if (name.length < 2 || name.length > 100) throw httpError(400, 'Nama harus 2-100 karakter.');
  if (!EMAIL_RE.test(email) || email.length > 254) throw httpError(400, 'Format email tidak valid.');
  if (password.length < 8) throw httpError(400, 'Kata sandi minimal 8 karakter.');
  if (password.length > 72) throw httpError(400, 'Kata sandi maksimal 72 karakter.');
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) throw httpError(409, 'Email sudah terdaftar.');
  const user = { id: crypto.randomUUID(), name, email, password_hash: bcrypt.hashSync(password, 10), interests: JSON.stringify(interests) };
  try {
    db.prepare('INSERT INTO users (id,name,email,password_hash,interests) VALUES (@id,@name,@email,@password_hash,@interests)').run(user);
  } catch (e) {
    if (e.code === 'SQLITE_CONSTRAINT_UNIQUE') throw httpError(409, 'Email sudah terdaftar.');
    throw e;
  }
  res.status(201).json({ token: signToken(user), user: publicUser(user) });
}));

api.post('/auth/login', authLimiter, wrap((req, res) => {
  const email = str(req.body.email).toLowerCase(), password = typeof req.body.password === 'string' ? req.body.password : '';
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  const ok = bcrypt.compareSync(password, user ? user.password_hash : DUMMY_HASH);
  if (!user || !ok) throw httpError(401, 'Email atau kata sandi salah.');
  res.json({ token: signToken(user), user: publicUser(user) });
}));

// Semua rute di bawah memerlukan login (aplikasi hanya menampilkannya setelah masuk).
api.use(auth);

api.get('/contents', wrap((req, res) => {
  const type = str(req.query.type), q = str(req.query.q).slice(0, 100);
  if (type && !['movie', 'series', 'music'].includes(type)) throw httpError(400, 'Tipe konten tidak valid.');
  const where = [], params = [];
  if (type) { where.push('c.type = ?'); params.push(type); }
  if (q) {
    const like = '%' + q.replace(/[\\%_]/g, '\\$&') + '%';
    where.push(`(c.title LIKE ? ESCAPE '\\' OR c.synopsis LIKE ? ESCAPE '\\' OR EXISTS (SELECT 1 FROM content_genres g WHERE g.content_id = c.id AND g.genre LIKE ? ESCAPE '\\'))`);
    params.push(like, like, like);
  }
  const rows = db.prepare(`${SUMMARY} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY c.title LIMIT 200`).all(...params);
  res.json(rows.map(withGenres));
}));

api.get('/contents/:id', wrap((req, res) => {
  const row = db.prepare(`${SUMMARY} WHERE c.id = ?`).get(req.params.id);
  if (!row) throw httpError(404, 'Konten tidak ditemukan.');
  const extra = db.prepare('SELECT synopsis, trailer_url AS trailerUrl FROM contents WHERE id = ?').get(row.id);
  const mine = db.prepare('SELECT value FROM ratings WHERE user_id = ? AND content_id = ?').get(req.user.id, row.id);
  const fav = db.prepare('SELECT 1 FROM favorites WHERE user_id = ? AND content_id = ?').get(req.user.id, row.id);
  const reviews = db.prepare(`SELECT r.id, u.name, r.text, r.created_at AS createdAt FROM reviews r JOIN users u ON u.id = r.user_id
                              WHERE r.content_id = ? ORDER BY r.created_at DESC, r.rowid DESC LIMIT 50`).all(row.id);
  res.json({ ...withGenres(row), ...extra, myRating: mine ? mine.value : 0, isFavorite: !!fav, reviews });
}));

api.post('/contents/:id/rate', wrap((req, res) => {
  needContent(req.params.id);
  const value = req.body.value;
  if (!Number.isInteger(value) || value < 1 || value > 5) throw httpError(400, 'Rating harus bilangan bulat 1-5.');
  db.prepare(`INSERT INTO ratings (user_id,content_id,value) VALUES (?,?,?)
              ON CONFLICT(user_id,content_id) DO UPDATE SET value = excluded.value, updated_at = strftime('%Y-%m-%dT%H:%M:%SZ','now')`)
    .run(req.user.id, req.params.id, value);
  res.json({ ok: true });
}));

api.post('/contents/:id/reviews', wrap((req, res) => {
  needContent(req.params.id);
  const text = str(req.body.text);
  if (!text) throw httpError(400, 'Ulasan tidak boleh kosong.');
  if (text.length > 1000) throw httpError(400, 'Ulasan maksimal 1000 karakter.');
  const id = crypto.randomUUID();
  db.prepare('INSERT INTO reviews (id,user_id,content_id,text) VALUES (?,?,?,?)').run(id, req.user.id, req.params.id, text);
  res.status(201).json({ id, name: req.user.name, text });
}));

api.get('/favorites', wrap((req, res) => {
  const rows = db.prepare(`${SUMMARY} JOIN favorites f ON f.content_id = c.id WHERE f.user_id = ? ORDER BY f.created_at DESC, f.rowid DESC`).all(req.user.id);
  res.json(rows.map(withGenres));
}));

api.post('/favorites/:id', wrap((req, res) => {
  needContent(req.params.id);
  db.prepare('INSERT OR IGNORE INTO favorites (user_id,content_id) VALUES (?,?)').run(req.user.id, req.params.id);
  res.status(201).json({ ok: true });
}));

api.delete('/favorites/:id', wrap((req, res) => {
  db.prepare('DELETE FROM favorites WHERE user_id = ? AND content_id = ?').run(req.user.id, req.params.id);
  res.json({ ok: true });
}));

app.use('/api', api);
app.use('/api', (_req, _res, next) => next(httpError(404, 'Rute tidak ditemukan.')));

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ message: 'JSON tidak valid.' });
  if (err.type === 'entity.too.large') return res.status(413).json({ message: 'Permintaan terlalu besar.' });
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ message: status >= 500 ? 'Terjadi kesalahan pada server.' : err.message });
});

if (require.main === module) {
  const server = app.listen(PORT, '0.0.0.0', () => console.log(`Entertainment Hub API di http://0.0.0.0:${PORT}/api`));
  const stop = () => server.close(() => { db.close(); process.exit(0); });
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}
module.exports = app;
