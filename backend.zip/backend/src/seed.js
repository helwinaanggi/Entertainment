const crypto = require('crypto');
const db = require('./db');

// Sinopsis ditulis ulang secara singkat. trailer_url diisi null; isi dengan URL embed
// (mis. https://www.youtube.com/embed/<ID>) lewat tabel contents bila diinginkan.
const items = [
  ['movie', 'Inception', 2010, '#1E3A5F', ['Aksi', 'Sci-Fi'], 'Seorang pencuri yang menyusup ke dalam mimpi diberi tugas terakhir: menanamkan sebuah gagasan ke benak target.'],
  ['movie', 'The Dark Knight', 2008, '#1F2937', ['Aksi', 'Drama'], 'Batman menghadapi penjahat anarkis yang mendorong Gotham ke tepi kekacauan.'],
  ['movie', 'Interstellar', 2014, '#0F4C5C', ['Sci-Fi', 'Drama'], 'Sekelompok astronot menembus lubang cacing demi mencari rumah baru bagi umat manusia.'],
  ['movie', 'Parasite', 2019, '#3F6212', ['Drama', 'Thriller'], 'Keluarga miskin menyusup perlahan ke kehidupan keluarga kaya, dengan akibat yang tak terduga.'],
  ['movie', 'Spirited Away', 2001, '#9A3412', ['Animasi', 'Fantasi'], 'Seorang gadis kecil terjebak di dunia roh dan harus bekerja untuk menyelamatkan orang tuanya.'],
  ['movie', 'Mad Max: Fury Road', 2015, '#B45309', ['Aksi'], 'Pengejaran tanpa henti melintasi gurun pasca-apokaliptik demi kebebasan.'],
  ['movie', 'La La Land', 2016, '#6D28D9', ['Drama', 'Musikal', 'Romansa'], 'Pianis jazz dan calon aktris jatuh cinta sambil mengejar mimpi masing-masing di Los Angeles.'],
  ['movie', 'Joker', 2019, '#7F1D1D', ['Drama', 'Thriller'], 'Seorang komedian gagal perlahan berubah menjadi sosok yang mengguncang kota.'],
  ['series', 'Breaking Bad', 2008, '#14532D', ['Drama', 'Kriminal'], 'Guru kimia yang didiagnosis kanker terjun ke dunia pembuatan narkoba demi masa depan keluarganya.'],
  ['series', 'Stranger Things', 2016, '#9F1239', ['Sci-Fi', 'Drama', 'Horor'], 'Anak-anak sebuah kota kecil menyingkap eksperimen rahasia dan dimensi gelap di baliknya.'],
  ['series', 'The Crown', 2016, '#1E40AF', ['Drama', 'Sejarah'], 'Kisah kerajaan Inggris dari masa muda sang ratu hingga dekade-dekade penuh gejolak.'],
  ['series', 'Money Heist', 2017, '#B91C1C', ['Aksi', 'Kriminal', 'Thriller'], 'Sekelompok perampok dipimpin sang Profesor merencanakan perampokan besar di percetakan uang.'],
  ['series', 'Squid Game', 2021, '#BE185D', ['Drama', 'Thriller'], 'Ratusan orang berutang ikut permainan anak-anak mematikan demi hadiah besar.'],
  ['series', 'Avatar: The Last Airbender', 2005, '#0E7490', ['Animasi', 'Aksi', 'Fantasi'], 'Seorang Avatar muda harus menguasai empat elemen untuk menghentikan perang.'],
  ['series', 'Dark', 2017, '#374151', ['Sci-Fi', 'Thriller', 'Drama'], 'Hilangnya anak-anak di kota Jerman membuka rahasia lintas waktu empat keluarga.'],
  ['music', 'Thriller - Michael Jackson', 1982, '#581C87', ['Pop'], 'Album pop terlaris sepanjang masa dengan Billie Jean, Beat It, dan lagu judulnya.'],
  ['music', 'Abbey Road - The Beatles', 1969, '#065F46', ['Rock', 'Pop'], 'Album terakhir yang direkam The Beatles, dengan medley sisi kedua yang ikonik.'],
  ['music', 'Rumours - Fleetwood Mac', 1977, '#92400E', ['Rock', 'Pop'], 'Album yang lahir dari konflik pribadi para anggota band, penuh harmoni dan emosi.'],
  ['music', 'Random Access Memories - Daft Punk', 2013, '#A16207', ['Elektronik', 'Pop'], 'Pulang ke sentuhan musisi sungguhan dengan nuansa disko dan funk.'],
  ['music', 'Divide - Ed Sheeran', 2017, '#0369A1', ['Pop'], 'Album pop akustik dengan Shape of You dan Castle on the Hill.'],
  ['music', 'Future Nostalgia - Dua Lipa', 2020, '#C026D3', ['Pop', 'Disko'], 'Pop-disko modern penuh bassline berdenyut dan hook yang menempel.'],
  ['music', 'Hybrid Theory - Linkin Park', 2000, '#334155', ['Rock'], 'Debut nu-metal dengan perpaduan gitar berat, rap, dan melodi vokal.'],
];

const insContent = db.prepare('INSERT INTO contents (id,title,type,year,color,synopsis) VALUES (?,?,?,?,?,?)');
const insGenre = db.prepare('INSERT OR IGNORE INTO content_genres (content_id,genre) VALUES (?,?)');

db.transaction(() => {
  if (process.argv.includes('--reset')) db.exec('DELETE FROM contents');
  const have = new Set(db.prepare('SELECT title FROM contents').all().map((r) => r.title));
  let n = 0;
  for (const [type, title, year, color, genres, synopsis] of items) {
    if (have.has(title)) continue;
    const id = crypto.randomUUID();
    insContent.run(id, title, type, year, color, synopsis);
    genres.forEach((g) => insGenre.run(id, g));
    n++;
  }
  console.log(`Seed selesai: ${n} konten ditambahkan.`);
})();
